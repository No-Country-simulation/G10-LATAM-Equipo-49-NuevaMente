# Guía: NuevaMente en Oracle Cloud Always Free (desde la consola)

Resultado final: una VM gratuita con la **UI Streamlit** (puerto 8501) y la **API FastAPI** (puerto 8000) como servicios que arrancan solos, y un **bucket de Object Storage** para documentos y resultados.

```
Internet ──► :8501  Streamlit (UI) ──► 127.0.0.1:8000  FastAPI (backend) ──► Chroma + SQLite (disco de la VM)
                                                                     └────► Object Storage (bucket nuevamente-g10)
```

> Hay dos caminos: **A) Todo con scripts** (sección 7, recomendado) o **B) A mano desde la consola** (secciones 2 a 6). Las secciones 1, 6 y 8 aplican a ambos.

---

## 1. Antes de empezar

- Cuenta de Oracle Cloud con **Always Free** (https://signup.cloud.oracle.com). Pide tarjeta solo para verificar identidad.
- **Elige bien la región de origen (home region)**: no se puede cambiar después y la capacidad gratuita ARM varía por región.
- Recursos Always Free que usaremos: VM Ampere **A1.Flex** (hasta 4 OCPU y 24 GB en total), hasta 200 GB de disco, 20 GB de Object Storage, 1 VCN.
- Requisito del proyecto: **Python ≥ 3.11** → usa **Ubuntu 24.04** (Ubuntu 22.04 trae 3.10 y no sirve).
- Idea de tamaño: **2 OCPU / 12 GB** sobra para este proyecto y deja margen para otra VM gratuita.

## 2. Crear la red (VCN)

1. Menú ☰ → **Networking → Virtual cloud networks → Start VCN Wizard**.
2. **Create VCN with Internet Connectivity** → *Start VCN Wizard*.
3. Nombre `nuevamente-vcn`, compartimento el que uses (el raíz sirve), bloques por defecto (`10.0.0.0/16`, pública `10.0.0.0/24`) → *Next → Create*.

## 3. Abrir los puertos (Security List)

1. En la VCN → subred pública → **Default Security List** → **Add Ingress Rules**.
2. Agrega estas reglas (Source Type *CIDR*, protocolo *TCP*, Source Port Range vacío):

| Source CIDR | Destination Port | Para qué |
|---|---|---|
| `0.0.0.0/0` (mejor: `TU_IP/32`) | `22` | SSH (ya viene creada) |
| `0.0.0.0/0` (o `TU_IP/32`) | `8501` | UI Streamlit |
| `TU_IP/32` — **solo si quieres la API pública** | `8000` | API FastAPI |

> ⚠️ La API **no tiene autenticación**. No la abras a `0.0.0.0/0`; limítala a tu IP o déjala cerrada (la UI la usa por dentro).

## 4. Crear el bucket (Object Storage)

1. ☰ → **Storage → Object Storage & Archive Storage → Buckets → Create Bucket**.
2. Nombre **`nuevamente-g10`** (es el que espera `OCI_BUCKET_NAME`), tier *Standard*, cifrado por defecto → *Create*.
3. Anota el **Namespace** (aparece en la pantalla del bucket).

## 5. Crear la instancia (Compute)

1. ☰ → **Compute → Instances → Create instance**.
2. **Name**: `nuevamente`.
3. **Image and shape → Edit**:
   - *Image* → **Change image → Canonical Ubuntu → 24.04** (aarch64 / "Minimal aarch64" también sirve).
   - *Shape* → **Change shape → Ampere → VM.Standard.A1.Flex** → **2 OCPU, 12 GB** (marca "Always Free-eligible").
4. **Networking**: VCN `nuevamente-vcn`, subred **pública**, **Automatically assign public IPv4 address** activado.
5. **Add SSH keys**: *Generate a key pair for me* → **descarga la clave privada** (`.key`) y guárdala. (O pega tu clave pública.)
6. **Boot volume**: *Specify a custom boot volume size* → **100 GB**.
7. **Show advanced options → Management → Cloud-init script → Paste cloud-init script** → pega el contenido de `cloud-init.yaml` de esta carpeta.
8. **Create**. En 1-2 min pasa a *Running*; copia la **Public IP**.

### Si dice "Out of host capacity"
Es común en la capa gratuita ARM. Opciones, en orden:
1. Probar otro **Availability Domain** (en *Placement*).
2. Bajar a 1 OCPU / 6 GB e intentar de nuevo.
3. Reintentar en otra hora (de madrugada suele haber capacidad) o usar el script de la sección 7, que reintenta solo cada 60 s.
4. Pasar la cuenta a *Pay As You Go*: mientras no excedas los límites Always Free no se cobra, y suele mejorar la disponibilidad.

## 6. Credenciales para Object Storage (API key)

La app lee `~/.oci/config`, así que necesita una API key (no sirven las credenciales de Cloud Shell).

1. Esquina superior derecha → tu perfil → **My profile → API keys → Add API key → Generate API key pair**.
2. **Descarga la clave privada** (`.pem`) → *Add*.
3. Aparece la **Configuration file preview**. Copia de ahí: `user`, `fingerprint`, `tenancy`, `region`.
4. Tu usuario necesita permiso sobre el bucket. Si eres administrador del tenancy ya lo tienes; si no, pide una política como:
   `Allow group <tu-grupo> to manage objects in compartment <tu-compartimento> where target.bucket.name='nuevamente-g10'`

## 7. Camino A — Scripts (crea todo y despliega)

Se ejecuta en **OCI Cloud Shell** (icono `>_` arriba a la derecha): ya trae `oci`, `jq` y sesión iniciada.

1. En Cloud Shell: **⚙ → Upload** y sube el zip del proyecto; descomprímelo y copia esta carpeta `deploy/` dentro de la raíz del proyecto (`nuevamente/deploy/oci/...`).
2. Crea red, VM y bucket (reintenta solo si no hay capacidad):
   ```bash
   cd nuevamente/deploy/oci
   # Opcional: restringe accesos a tu IP (curl ifconfig.me)
   # export UI_CIDR=TU_IP/32 SSH_CIDR=0.0.0.0/0
   bash create_instance.sh
   ```
3. Sube el `.pem` de la sección 6 a Cloud Shell (⚙ → Upload) y despliega:
   ```bash
   export OCI_USER_OCID=ocid1.user.oc1..xxxx
   export OCI_TENANCY_OCID=ocid1.tenancy.oc1..xxxx
   export OCI_FINGERPRINT=aa:bb:cc:...
   export OCI_REGION=us-ashburn-1
   export OCI_API_KEY_PEM=~/oci_api_key.pem
   export GEMINI_API_KEY=xxxx        # opcional; sin ella corre en modo mock
   bash deploy_app.sh
   ```
4. Al final imprime `http://IP:8501` y hace una **ingesta de prueba**.

Para publicar también la API: antes del paso 2 usa `API_CIDR=TU_IP/32`.
Para redeplegar tras cambiar código: vuelve a correr `deploy_app.sh` (conserva `data/`).

### Camino B — a mano
Después de la sección 5, desde tu terminal (clave descargada en la sección 5):
```bash
ssh -i ~/ruta/ssh-key.key ubuntu@IP_PUBLICA
cat /var/lib/nuevamente-ready        # existe cuando cloud-init terminó
```
Copia el proyecto (`scp -i ... nuevamente.zip ubuntu@IP:/tmp/`), descomprímelo en `/opt/nuevamente/app`, crea `/opt/nuevamente/app/.env` con el contenido de la sección 9 y ejecuta `bash remote_setup.sh` (en la VM).

## 8. Verificar

- UI: `http://IP_PUBLICA:8501` → sube `ejemplos/sample_contenedores.md` y genera contenido.
- Salud de la API (desde la VM): `curl http://127.0.0.1:8000/health` → `{"status":"ok"}`.
- Bucket: consola → *Object Storage → nuevamente-g10* → deben aparecer objetos del tipo `{tipo}/{doc_id}/{timestamp}_{nombre}`.
- Si en la UI el resultado dice **PARTIAL** o aviso de mock, el documento no estaba indexado; ver sección 10.

Comandos útiles en la VM:
```bash
sudo systemctl status nuevamente-api nuevamente-ui
sudo journalctl -u nuevamente-api -f
sudo systemctl restart nuevamente-api nuevamente-ui
```

## 9. Configuración (`/opt/nuevamente/app/.env`)

```ini
ENVIRONMENT=production
VECTORSTORE_PROVIDER=chroma        # persiste; con "memory" se pierde el índice al reiniciar
LLM_PROVIDER=gemini                # o mock
EMBEDDING_PROVIDER=gemini          # o mock
GEMINI_API_KEY=...
STORAGE_PROVIDER=oci               # o mock (disco de la VM)
OCI_CONFIG_FILE=/home/ubuntu/.oci/config
OCI_BUCKET_NAME=nuevamente-g10
OCI_NAMESPACE=<tu namespace>
```
Tras editarlo: `sudo systemctl restart nuevamente-api`.
Si cambias de proveedor de embeddings, Chroma crea una colección distinta (por nombre y dimensiones): vuelve a ingestar los documentos.

## 10. Problemas frecuentes

| Síntoma | Causa / solución |
|---|---|
| La UI no abre desde el navegador | Falta la regla 8501 en la Security List **o** el firewall del SO. El `cloud-init.yaml` ya abre 8501/8000 con iptables; compruébalo: `sudo iptables -L INPUT -n --line-numbers` |
| "No fue posible conectar con la API" en la UI | `sudo systemctl status nuevamente-api`; revisa `journalctl` |
| `STORAGE_ERROR` al subir | Config OCI errónea: revisa `~/.oci/config`, ruta del `.pem` (`/home/ubuntu/.oci/oci_api_key.pem`), permisos del usuario y nombre del bucket |
| Resultado `PARTIAL` tras reiniciar | Estás con `VECTORSTORE_PROVIDER=memory`; usa `chroma` y reingesta |
| `pip install` falla compilando | `sudo apt-get install -y build-essential python3-dev` y repite `remote_setup.sh` |
| Se queda sin memoria | El cloud-init crea 4 GB de swap; sube a 3-4 OCPU / 18-24 GB si hace falta |

## 11. Límites y buenas prácticas Always Free

- Oracle puede **reclamar instancias Always Free inactivas** (uso bajo de CPU/red/memoria sostenido durante ~7 días). Si es una demo, entra y úsala de vez en cuando.
- La capa gratuita no incluye respaldo: haz copia de `/opt/nuevamente/app/data` si importa.
- HTTP plano en :8501 es suficiente para pruebas. Para producción, agrega un dominio + proxy inverso con HTTPS (Caddy/nginx) y autenticación en la API.
- **Limpiar todo**: Compute → Instances → *Terminate* (marca "borrar boot volume"); luego VCN y bucket (vacío) desde sus pantallas.
