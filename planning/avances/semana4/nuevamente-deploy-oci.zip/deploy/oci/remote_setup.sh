#!/usr/bin/env bash
# Se ejecuta DENTRO de la VM (lo lanza deploy_app.sh). Instala dependencias y
# deja backend + UI como servicios systemd que arrancan solos con la VM.
set -euo pipefail

BASE=/opt/nuevamente
APP=$BASE/app
VENV=$BASE/venv
EXPOSE_API="${EXPOSE_API:-false}"
UI_PORT="${UI_PORT:-8501}"
API_PORT="${API_PORT:-8000}"
USER_NAME="$(id -un)"

echo "==> Entorno virtual y dependencias (puede tardar varios minutos)"
[[ -d $VENV ]] || python3 -m venv "$VENV"
"$VENV/bin/pip" install -q --upgrade pip
# requirements-oci.txt ya incluye requirements.txt. chromadb se acota a <1.0 como
# en requirements-rag.txt (en requirements.txt va sin límite de versión).
"$VENV/bin/pip" install -q -r "$APP/backend/requirements-oci.txt" "chromadb>=0.5,<1.0"

mkdir -p "$APP/data"

echo "==> Servicios systemd"
if [[ "$EXPOSE_API" == "true" ]]; then API_HOST=0.0.0.0; else API_HOST=127.0.0.1; fi
cat >"$BASE/service.env" <<ENV
API_HOST=$API_HOST
API_PORT=$API_PORT
UI_PORT=$UI_PORT
API_URL=http://127.0.0.1:$API_PORT
ENV

sudo tee /etc/systemd/system/nuevamente-api.service >/dev/null <<UNIT
[Unit]
Description=NuevaMente API (FastAPI)
After=network-online.target
Wants=network-online.target

[Service]
User=$USER_NAME
WorkingDirectory=$APP/backend
EnvironmentFile=$BASE/service.env
# 1 solo worker: la base SQLite y los jobs en segundo plano viven en este proceso.
ExecStart=$VENV/bin/python -m uvicorn src.api.main:app --host \${API_HOST} --port \${API_PORT} --workers 1
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT

sudo tee /etc/systemd/system/nuevamente-ui.service >/dev/null <<UNIT
[Unit]
Description=NuevaMente UI (Streamlit)
After=nuevamente-api.service
Wants=nuevamente-api.service

[Service]
User=$USER_NAME
WorkingDirectory=$APP
EnvironmentFile=$BASE/service.env
ExecStart=$VENV/bin/python -m streamlit run ui/app.py --server.address 0.0.0.0 --server.port \${UI_PORT} --server.headless true --browser.gatherUsageStats false
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable nuevamente-api nuevamente-ui >/dev/null
sudo systemctl restart nuevamente-api nuevamente-ui

echo "==> Esperando a la API"
for _ in $(seq 1 30); do
  if curl -fsS "http://127.0.0.1:$API_PORT/health" >/dev/null 2>&1; then
    echo "API OK: $(curl -fsS http://127.0.0.1:$API_PORT/health)"
    exit 0
  fi
  sleep 2
done
echo "La API no respondió. Revisa: sudo journalctl -u nuevamente-api -n 80 --no-pager" >&2
exit 1
