#!/usr/bin/env bash
# =============================================================================
# NuevaMente — Crea en Oracle Cloud (Always Free) la red, la VM y el bucket.
#
# Dónde ejecutarlo: OCI Cloud Shell (icono ">_" de la consola). Ya trae el CLI
# `oci`, `jq` y la sesión iniciada. También funciona en tu PC si tienes
# `oci setup config` hecho.
#
# Uso:   bash create_instance.sh
# Ajustes opcionales (variables de entorno), por ejemplo:
#   OCPUS=4 MEMORY_GB=24 bash create_instance.sh
#   UI_CIDR=203.0.113.7/32 SSH_CIDR=203.0.113.7/32 bash create_instance.sh
#   API_CIDR=203.0.113.7/32 bash create_instance.sh   # expone también la API
# =============================================================================
set -euo pipefail

# ---------------------------- Parámetros -------------------------------------
NAME="${NAME:-nuevamente}"
SHAPE="${SHAPE:-VM.Standard.A1.Flex}"      # Always Free ARM (hasta 4 OCPU / 24 GB en total)
OCPUS="${OCPUS:-2}"
MEMORY_GB="${MEMORY_GB:-12}"
BOOT_GB="${BOOT_GB:-100}"                  # Always Free: 200 GB de disco en total
OS_NAME="${OS_NAME:-Canonical Ubuntu}"
OS_VERSION="${OS_VERSION:-24.04}"          # Python 3.12 (el proyecto exige >= 3.11)
SSH_CIDR="${SSH_CIDR:-0.0.0.0/0}"          # Quién puede entrar por SSH (22)
UI_CIDR="${UI_CIDR:-0.0.0.0/0}"            # Quién puede abrir Streamlit (8501)
API_CIDR="${API_CIDR:-}"                   # Vacío = la API NO se publica en internet
UI_PORT="${UI_PORT:-8501}"
API_PORT="${API_PORT:-8000}"
BUCKET_NAME="${BUCKET_NAME:-nuevamente-g10}"
SSH_KEY_PATH="${SSH_KEY_PATH:-$HOME/.ssh/nuevamente_key}"
RETRY_SECONDS="${RETRY_SECONDS:-60}"       # Espera entre reintentos por falta de capacidad
MAX_ATTEMPTS="${MAX_ATTEMPTS:-60}"         # 60 intentos x 60 s = 1 hora

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INFO_FILE="$HERE/.instance_info"

log() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
die() { printf '\033[1;31mERROR: %b\033[0m\n' "$*" >&2; exit 1; }

# ---------------------------- Requisitos -------------------------------------
command -v oci >/dev/null || die "No encuentro el CLI 'oci'. Usa OCI Cloud Shell."
command -v jq  >/dev/null || die "Falta 'jq'."
command -v ssh-keygen >/dev/null || die "Falta 'ssh-keygen'."

# Compartimento: por defecto el raíz (= tenancy). Puedes fijar COMPARTMENT_OCID.
if [[ -z "${COMPARTMENT_OCID:-}" ]]; then
  COMPARTMENT_OCID="${OCI_TENANCY:-${OCI_CLI_TENANCY:-}}"
  if [[ -z "$COMPARTMENT_OCID" && -f "$HOME/.oci/config" ]]; then
    COMPARTMENT_OCID="$(awk -F= '/^tenancy/{gsub(/ /,"",$2); print $2; exit}' "$HOME/.oci/config")"
  fi
fi
[[ -n "$COMPARTMENT_OCID" ]] || die "Define COMPARTMENT_OCID=ocid1.compartment..."
log "Compartimento: $COMPARTMENT_OCID"

# ---------------------------- Clave SSH --------------------------------------
if [[ ! -f "$SSH_KEY_PATH" ]]; then
  log "Generando clave SSH en $SSH_KEY_PATH"
  mkdir -p "$(dirname "$SSH_KEY_PATH")"
  ssh-keygen -t ed25519 -N "" -f "$SSH_KEY_PATH" -C "$NAME" >/dev/null
fi
[[ -f "$SSH_KEY_PATH.pub" ]] || die "Falta $SSH_KEY_PATH.pub"

# ---------------------------- Red (VCN) --------------------------------------
log "Red virtual (VCN, gateway, reglas, subred)"
VCN_ID="$(oci network vcn list --compartment-id "$COMPARTMENT_OCID" --display-name "$NAME-vcn" \
  --lifecycle-state AVAILABLE --query 'data[0].id' --raw-output 2>/dev/null || true)"

if [[ -z "$VCN_ID" || "$VCN_ID" == "null" ]]; then
  VCN_ID="$(oci network vcn create --compartment-id "$COMPARTMENT_OCID" \
    --cidr-block 10.0.0.0/16 --display-name "$NAME-vcn" --dns-label "${NAME//[^a-z0-9]/}vcn" \
    --wait-for-state AVAILABLE --query 'data.id' --raw-output)"
  echo "VCN creada: $VCN_ID"
else
  echo "VCN existente reutilizada: $VCN_ID"
fi

IGW_ID="$(oci network internet-gateway list --compartment-id "$COMPARTMENT_OCID" --vcn-id "$VCN_ID" \
  --query 'data[0].id' --raw-output 2>/dev/null || true)"
if [[ -z "$IGW_ID" || "$IGW_ID" == "null" ]]; then
  IGW_ID="$(oci network internet-gateway create --compartment-id "$COMPARTMENT_OCID" --vcn-id "$VCN_ID" \
    --is-enabled true --display-name "$NAME-igw" --wait-for-state AVAILABLE \
    --query 'data.id' --raw-output)"
fi

VCN_JSON="$(oci network vcn get --vcn-id "$VCN_ID")"
RT_ID="$(jq -r '.data["default-route-table-id"]' <<<"$VCN_JSON")"
SL_ID="$(jq -r '.data["default-security-list-id"]' <<<"$VCN_JSON")"

oci network route-table update --rt-id "$RT_ID" --force \
  --route-rules "[{\"destination\":\"0.0.0.0/0\",\"destinationType\":\"CIDR_BLOCK\",\"networkEntityId\":\"$IGW_ID\"}]" \
  >/dev/null

tcp_rule() { # $1=cidr $2=puerto $3=descripcion
  jq -n --arg c "$1" --argjson p "$2" --arg d "$3" \
    '{source:$c,sourceType:"CIDR_BLOCK",protocol:"6",isStateless:false,description:$d,
      tcpOptions:{destinationPortRange:{min:$p,max:$p}}}'
}
RULES="$(tcp_rule "$SSH_CIDR" 22 "SSH" | jq -s '.')"
RULES="$(jq --argjson r "$(tcp_rule "$UI_CIDR" "$UI_PORT" "Streamlit UI")" '. + [$r]' <<<"$RULES")"
if [[ -n "$API_CIDR" ]]; then
  RULES="$(jq --argjson r "$(tcp_rule "$API_CIDR" "$API_PORT" "API FastAPI")" '. + [$r]' <<<"$RULES")"
fi
oci network security-list update --security-list-id "$SL_ID" --force \
  --ingress-security-rules "$RULES" \
  --egress-security-rules '[{"destination":"0.0.0.0/0","destinationType":"CIDR_BLOCK","protocol":"all","isStateless":false}]' \
  >/dev/null
echo "Reglas de entrada: SSH($SSH_CIDR) UI($UI_CIDR)${API_CIDR:+ API($API_CIDR)}"

SUBNET_ID="$(oci network subnet list --compartment-id "$COMPARTMENT_OCID" --vcn-id "$VCN_ID" \
  --display-name "$NAME-subnet" --query 'data[0].id' --raw-output 2>/dev/null || true)"
if [[ -z "$SUBNET_ID" || "$SUBNET_ID" == "null" ]]; then
  SUBNET_ID="$(oci network subnet create --compartment-id "$COMPARTMENT_OCID" --vcn-id "$VCN_ID" \
    --cidr-block 10.0.1.0/24 --display-name "$NAME-subnet" --dns-label "${NAME//[^a-z0-9]/}sn" \
    --prohibit-public-ip-on-vnic false --route-table-id "$RT_ID" --security-list-ids "[\"$SL_ID\"]" \
    --wait-for-state AVAILABLE --query 'data.id' --raw-output)"
fi
echo "Subred: $SUBNET_ID"

# ---------------------------- Imagen -----------------------------------------
log "Buscando imagen $OS_NAME $OS_VERSION compatible con $SHAPE"
IMAGE_ID="$(oci compute image list --compartment-id "$COMPARTMENT_OCID" \
  --operating-system "$OS_NAME" --operating-system-version "$OS_VERSION" --shape "$SHAPE" \
  --sort-by TIMECREATED --sort-order DESC --limit 1 --query 'data[0].id' --raw-output)"
[[ -n "$IMAGE_ID" && "$IMAGE_ID" != "null" ]] || die "No hay imagen $OS_NAME $OS_VERSION para $SHAPE en esta región."
echo "Imagen: $IMAGE_ID"

# ---------------------------- Bucket de Object Storage ------------------------
log "Bucket de Object Storage '$BUCKET_NAME'"
NAMESPACE="$(oci os ns get --query 'data' --raw-output)"
if oci os bucket get --namespace-name "$NAMESPACE" --bucket-name "$BUCKET_NAME" >/dev/null 2>&1; then
  echo "Bucket existente reutilizado."
else
  oci os bucket create --namespace-name "$NAMESPACE" --compartment-id "$COMPARTMENT_OCID" \
    --name "$BUCKET_NAME" --storage-tier Standard >/dev/null
  echo "Bucket creado."
fi

# ---------------------------- Instancia --------------------------------------
log "Lanzando la instancia ($SHAPE, ${OCPUS} OCPU, ${MEMORY_GB} GB)"
SHAPE_ARGS=()
if [[ "$SHAPE" == *Flex ]]; then
  SHAPE_ARGS=(--shape-config "{\"ocpus\":$OCPUS,\"memoryInGBs\":$MEMORY_GB}")
fi

mapfile -t ADS < <(oci iam availability-domain list --compartment-id "$COMPARTMENT_OCID" \
  --query 'data[].name' | jq -r '.[]')
[[ ${#ADS[@]} -gt 0 ]] || die "No pude listar los Availability Domains."

INSTANCE_ID=""
for ((attempt = 1; attempt <= MAX_ATTEMPTS; attempt++)); do
  for AD in "${ADS[@]}"; do
    echo "Intento $attempt/$MAX_ATTEMPTS en $AD ..."
    if OUT="$(oci compute instance launch \
        --availability-domain "$AD" --compartment-id "$COMPARTMENT_OCID" \
        --display-name "$NAME" --shape "$SHAPE" "${SHAPE_ARGS[@]}" \
        --image-id "$IMAGE_ID" --subnet-id "$SUBNET_ID" --assign-public-ip true \
        --boot-volume-size-in-gbs "$BOOT_GB" \
        --ssh-authorized-keys-file "$SSH_KEY_PATH.pub" \
        --user-data-file "$HERE/cloud-init.yaml" \
        --wait-for-state RUNNING 2>&1)"; then
      INSTANCE_ID="$(jq -r '.data.id' <<<"$OUT")"
      break 2
    fi
    if grep -qiE "out of (host )?capacity|OutOfHostCapacity|LimitExceeded.*capacity" <<<"$OUT"; then
      echo "  Sin capacidad por ahora en $AD."
    elif grep -qiE "LimitExceeded|QuotaExceeded" <<<"$OUT"; then
      die "Límite del servicio alcanzado (¿ya tienes una A1 o usas más de 4 OCPU/24 GB?):\n$OUT"
    else
      die "Falló el lanzamiento:\n$OUT"
    fi
  done
  sleep "$RETRY_SECONDS"
done
[[ -n "$INSTANCE_ID" ]] || die "No se logró crear la instancia tras $MAX_ATTEMPTS intentos. Reintenta más tarde o prueba otro SHAPE."

PUBLIC_IP="$(oci compute instance list-vnics --instance-id "$INSTANCE_ID" \
  --query 'data[0]."public-ip"' --raw-output)"

cat >"$INFO_FILE" <<INFO
INSTANCE_ID=$INSTANCE_ID
PUBLIC_IP=$PUBLIC_IP
SSH_KEY_PATH=$SSH_KEY_PATH
BUCKET_NAME=$BUCKET_NAME
NAMESPACE=$NAMESPACE
UI_PORT=$UI_PORT
API_PORT=$API_PORT
EXPOSE_API=$([[ -n "$API_CIDR" ]] && echo true || echo false)
INFO

log "Instancia creada"
cat <<DONE
  IP pública : $PUBLIC_IP
  SSH        : ssh -i $SSH_KEY_PATH ubuntu@$PUBLIC_IP
  Bucket     : $BUCKET_NAME (namespace $NAMESPACE)
  Datos      : $INFO_FILE

La VM tarda 3-5 min en terminar su cloud-init (instala Python, firewall, etc.).
Siguiente paso:  bash deploy_app.sh
DONE
