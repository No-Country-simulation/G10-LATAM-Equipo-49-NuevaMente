#!/usr/bin/env bash
# =============================================================================
# NuevaMente — Sube el código a la VM, lo configura y levanta API + UI.
# Ejecutar DESPUÉS de create_instance.sh y desde el mismo lugar (Cloud Shell).
#
# Variables opcionales:
#   GEMINI_API_KEY=...            Usa Gemini (LLM + embeddings). Sin ella: modo mock.
#   OCI_USER_OCID=ocid1.user...   ┐ Credenciales de API key para guardar archivos
#   OCI_FINGERPRINT=aa:bb:...     │ en Object Storage (ver la guía, sección 6).
#   OCI_API_KEY_PEM=~/oci_key.pem ┘ Sin ellas: almacenamiento en disco (mock).
#   OCI_REGION=mx-queretaro-1     Región (por defecto, la del CLI).
# =============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
INFO="$HERE/.instance_info"
[[ -f "$INFO" ]] || { echo "Falta $INFO: ejecuta primero create_instance.sh" >&2; exit 1; }
# shellcheck disable=SC1090
source "$INFO"

SSH_OPTS=(-i "$SSH_KEY_PATH" -o StrictHostKeyChecking=accept-new -o ConnectTimeout=15)
REMOTE="ubuntu@$PUBLIC_IP"
log() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }

log "Esperando a que la VM termine su configuración inicial"
for _ in $(seq 1 60); do
  if ssh "${SSH_OPTS[@]}" "$REMOTE" 'test -f /var/lib/nuevamente-ready' 2>/dev/null; then break; fi
  sleep 10
done
ssh "${SSH_OPTS[@]}" "$REMOTE" 'test -f /var/lib/nuevamente-ready' \
  || { echo "La VM aún no está lista (cloud-init). Reintenta en unos minutos." >&2; exit 1; }

# ------------------------------ .env de producción ---------------------------
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
USE_OCI=false; [[ -n "${OCI_USER_OCID:-}" && -n "${OCI_FINGERPRINT:-}" && -n "${OCI_API_KEY_PEM:-}" ]] && USE_OCI=true
USE_GEMINI=false; [[ -n "${GEMINI_API_KEY:-}" ]] && USE_GEMINI=true

{
  echo "ENVIRONMENT=production"
  echo "LOG_LEVEL=INFO"
  echo "VECTORSTORE_PROVIDER=chroma"   # persiste en disco: sobrevive a reinicios
  echo "CHROMA_PERSIST_DIR=./data/chroma"
  echo "DATABASE_URL=sqlite:///./data/sqlite/nuevamente.db"
  if $USE_GEMINI; then
    echo "LLM_PROVIDER=gemini"; echo "EMBEDDING_PROVIDER=gemini"; echo "GEMINI_API_KEY=$GEMINI_API_KEY"
  else
    echo "LLM_PROVIDER=mock"; echo "EMBEDDING_PROVIDER=mock"
  fi
  if $USE_OCI; then
    echo "STORAGE_PROVIDER=oci"
    echo "OCI_CONFIG_FILE=/home/ubuntu/.oci/config"
    echo "OCI_PROFILE=DEFAULT"
    echo "OCI_BUCKET_NAME=$BUCKET_NAME"
    echo "OCI_NAMESPACE=$NAMESPACE"
  else
    echo "STORAGE_PROVIDER=mock"
    echo "MOCK_STORAGE_DIR=./data/mock_oci"
  fi
} >"$TMP/.env"
chmod 600 "$TMP/.env"

# ------------------------------ Empaquetar y subir ---------------------------
log "Empaquetando el proyecto"
tar -C "$ROOT" -czf "$TMP/app.tgz" \
  --exclude='.venv' --exclude='venv' --exclude='__pycache__' --exclude='*.pyc' \
  --exclude='data' --exclude='.git' --exclude='.env' --exclude='*.pem' --exclude='.oci' \
  --exclude='docs' --exclude='docs-git' --exclude='n8n-workflows' --exclude='deploy' \
  --exclude='backend/tests' .

log "Subiendo a $PUBLIC_IP"
scp "${SSH_OPTS[@]}" -q "$TMP/app.tgz" "$TMP/.env" "$HERE/remote_setup.sh" "$REMOTE:/tmp/"
ssh "${SSH_OPTS[@]}" "$REMOTE" 'set -e
  mkdir -p /opt/nuevamente/app
  tar -xzf /tmp/app.tgz -C /opt/nuevamente/app
  install -m 600 /tmp/.env /opt/nuevamente/app/.env
  rm -f /tmp/app.tgz /tmp/.env'

if $USE_OCI; then
  log "Credenciales OCI para Object Storage"
  REGION="${OCI_REGION:-$(awk -F= '/^region/{gsub(/ /,"",$2); print $2; exit}' "$HOME/.oci/config" 2>/dev/null || true)}"
  [[ -n "$REGION" ]] || { echo "Define OCI_REGION (ej. us-ashburn-1)" >&2; exit 1; }
  TENANCY="${OCI_TENANCY_OCID:-${OCI_TENANCY:-}}"
  [[ -n "$TENANCY" ]] || { echo "Define OCI_TENANCY_OCID" >&2; exit 1; }
  cat >"$TMP/oci_config" <<CFG
[DEFAULT]
user=$OCI_USER_OCID
fingerprint=$OCI_FINGERPRINT
tenancy=$TENANCY
region=$REGION
key_file=/home/ubuntu/.oci/oci_api_key.pem
CFG
  ssh "${SSH_OPTS[@]}" "$REMOTE" 'mkdir -p ~/.oci && chmod 700 ~/.oci'
  scp "${SSH_OPTS[@]}" -q "$TMP/oci_config" "$REMOTE:.oci/config"
  scp "${SSH_OPTS[@]}" -q "${OCI_API_KEY_PEM/#\~/$HOME}" "$REMOTE:.oci/oci_api_key.pem"
  ssh "${SSH_OPTS[@]}" "$REMOTE" 'chmod 600 ~/.oci/config ~/.oci/oci_api_key.pem'
else
  echo "AVISO: sin credenciales OCI → los archivos se guardan en disco local de la VM (mock)."
fi

log "Instalando dependencias y levantando servicios"
ssh "${SSH_OPTS[@]}" "$REMOTE" "EXPOSE_API=$EXPOSE_API UI_PORT=$UI_PORT API_PORT=$API_PORT bash /tmp/remote_setup.sh"

# ------------------------------ Prueba de humo -------------------------------
log "Prueba de humo (ingesta del documento de ejemplo)"
SAMPLE="$ROOT/ejemplos/sample_contenedores.md"
if [[ -f "$SAMPLE" ]]; then
  scp "${SSH_OPTS[@]}" -q "$SAMPLE" "$REMOTE:/tmp/sample.md"
  ssh "${SSH_OPTS[@]}" "$REMOTE" "curl -fsS -F 'file=@/tmp/sample.md' http://127.0.0.1:$API_PORT/ingest; echo" \
    || echo "AVISO: la ingesta falló; revisa 'sudo journalctl -u nuevamente-api -n 80'"
fi

cat <<DONE

Listo.
  UI (Streamlit) : http://$PUBLIC_IP:$UI_PORT
  API            : $([[ "$EXPOSE_API" == "true" ]] && echo "http://$PUBLIC_IP:$API_PORT/docs" || echo "solo interna (127.0.0.1:$API_PORT). Para publicarla: API_CIDR=<tu_ip>/32 en create_instance.sh")
  Logs           : ssh -i $SSH_KEY_PATH $REMOTE 'sudo journalctl -u nuevamente-api -u nuevamente-ui -f'
DONE
