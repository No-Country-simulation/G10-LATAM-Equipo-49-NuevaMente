# Guía: crear la instancia Always Free en Oracle Cloud (desde la consola)

Objetivo: una VM gratuita Ubuntu 24.04 (ARM Ampere A1) con Python 3.12, accesible por SSH y con los puertos 8501 (UI) y 8000 (API) preparados. El bucket de Object Storage y el despliegue de la app quedan fuera de esta guía.

> Dos caminos: **A) Script** (`create_instance.sh`, sección 6) o **B) A mano en la consola** (secciones 2 a 5).

## 1. Antes de empezar
- Cuenta Oracle Cloud con **Always Free**. Elige bien la **región de origen**: no se puede cambiar y la capacidad ARM varía por región.
- Límite gratuito ARM: **4 OCPU y 24 GB en total**. Recomendado: **2 OCPU / 12 GB**.
- El proyecto exige **Python ≥ 3.11** → usa **Ubuntu 24.04** (la 22.04 trae 3.10).

## 2. Crear la red (VCN)
1. ☰ → **Networking → Virtual cloud networks → Start VCN Wizard**.
2. **Create VCN with Internet Connectivity** → nombre `nuevamente-vcn` → valores por defecto → *Next → Create*.

## 3. Abrir puertos (Security List)
VCN → subred pública → **Default Security List → Add Ingress Rules** (Source Type *CIDR*, protocolo *TCP*):

| Source CIDR | Puerto destino | Uso |
|---|---|---|
| `0.0.0.0/0` (mejor `TU_IP/32`) | 22 | SSH (ya existe) |
| `0.0.0.0/0` o `TU_IP/32` | 8501 | UI Streamlit |
| `TU_IP/32` (solo si la necesitas pública) | 8000 | API FastAPI (sin autenticación: no la abras a todo internet) |

## 4. Crear la instancia
1. ☰ → **Compute → Instances → Create instance**.
2. **Name**: `nuevamente`.
3. **Image and shape → Edit**:
   - *Change image* → **Canonical Ubuntu → 24.04**.
   - *Change shape* → **Ampere → VM.Standard.A1.Flex** → **2 OCPU, 12 GB**.
4. **Networking**: VCN `nuevamente-vcn`, subred pública, *Automatically assign public IPv4 address* activado.
5. **Add SSH keys**: *Generate a key pair for me* y **descarga la clave privada** (o pega tu clave pública).
6. **Boot volume**: tamaño personalizado **100 GB**.
7. **Show advanced options → Management → Cloud-init script → Paste cloud-init script**: pega `cloud-init.yaml` (instala Python/venv/pip/git, abre 8501 y 8000 en el firewall del sistema y crea 4 GB de swap).
8. **Create** y espera *Running*; copia la **Public IP**.

### "Out of host capacity"
Es habitual en ARM gratuito. En orden:
1. Cambia de **Availability Domain** (sección *Placement*).
2. Baja a 1 OCPU / 6 GB y vuelve a intentar.
3. Reintenta en otra hora (madrugada suele funcionar) o usa el script, que reintenta solo.
4. Pasa la cuenta a *Pay As You Go*: si no excedes los límites Always Free no se cobra, y suele mejorar la disponibilidad.

## 5. Verificar
```bash
chmod 600 ssh-key.key
ssh -i ssh-key.key ubuntu@IP_PUBLICA
python3 --version                      # 3.12.x
ls /var/lib/cloud-init-nuevamente-done # existe cuando cloud-init terminó
free -h                                # ~12 GB RAM + 4 GB swap
```
Si falta algo: `sudo tail -n 80 /var/log/cloud-init-output.log`.

## 6. Camino A — Script (recomendado)
En **OCI Cloud Shell** (icono `>_`, ya trae `oci`, `jq` y sesión):
1. ⚙ → **Upload** y sube la carpeta/zip `deploy/oci`; descomprime.
2. Ejecuta:
   ```bash
   cd deploy/oci
   bash create_instance.sh
   ```
   Crea VCN, gateway, rutas, reglas de seguridad, subred y la instancia (busca sola la imagen Ubuntu 24.04 ARM). Guarda IP y datos en `.instance_info` y genera la clave SSH en `~/.ssh/nuevamente_key`.

### Reintentos
Por defecto reintenta **cada 45 s hasta 2000 rondas (~1 día)**, recorre todos los Availability Domains, y ante errores transitorios (429, 5xx, cortes de red) espera con backoff creciente de hasta 5 min. Los errores definitivos (permisos, límites) detienen el script con el mensaje de OCI.

### Variables útiles
| Variable | Por defecto | Efecto |
|---|---|---|
| `MAX_ATTEMPTS` | 2000 | `0` = sin límite |
| `RETRY_SECONDS` | 45 | Pausa entre rondas |
| `OCPUS` / `MEMORY_GB` | 2 / 12 | Tamaño (máx. 4 / 24 en total) |
| `BOOT_GB` | 100 | Disco de arranque |
| `SSH_CIDR`, `UI_CIDR` | `0.0.0.0/0` | Quién entra a 22 y 8501 (usa `TU_IP/32`) |
| `API_CIDR` | vacío | Si se define, abre el 8000 para ese CIDR |
| `COMPARTMENT_OCID` | tenancy | Compartimento destino |
| `SHAPE` | `VM.Standard.A1.Flex` | Alternativa: `VM.Standard.E2.1.Micro` (1 GB RAM, justo) |

Cloud Shell se cierra por inactividad: para esperas largas ejecuta `nohup bash create_instance.sh > crear.log 2>&1 &` y revisa `tail -f crear.log`; o relanza el script (reutiliza VCN y subred existentes).

## 7. Notas Always Free
- Oracle puede reclamar instancias Always Free **inactivas** (uso bajo sostenido ~7 días).
- No hay respaldo automático del disco.
- Para limpiar: *Compute → Instances → Terminate* (marca borrar boot volume); luego subred, gateway y VCN.
